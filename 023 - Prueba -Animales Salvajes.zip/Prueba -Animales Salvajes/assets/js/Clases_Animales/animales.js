import { Animal } from './animal.js'
import { Leon } from './leon.js'
import { Lobo } from './lobo.js'
import { Oso } from './oso.js'
import { Serpiente } from './serpiente.js'
import { Aguila } from './aguila.js'

export { Animal, Leon, Lobo, Oso, Serpiente, Aguila }