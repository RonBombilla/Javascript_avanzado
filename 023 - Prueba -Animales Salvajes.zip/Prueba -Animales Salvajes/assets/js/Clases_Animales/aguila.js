import { Animal } from "./animal.js";

export class Aguila extends Animal{
    constructor(nombre, edad, imagen, comentarios, sonidos){
        super(nombre, edad, imagen, comentarios, sonidos);
    }

    chillar(){
        this.getSonido();
    }
}