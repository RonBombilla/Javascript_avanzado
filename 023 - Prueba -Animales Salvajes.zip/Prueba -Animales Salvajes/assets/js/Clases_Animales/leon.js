import { Animal } from "./animal.js";

export class Leon extends Animal{
    constructor(nombre, edad, imagen, comentarios, sonidos){
        super(nombre, edad, imagen, comentarios, sonidos)
    }

    aullar(){
        this.getSonido();
    }
}