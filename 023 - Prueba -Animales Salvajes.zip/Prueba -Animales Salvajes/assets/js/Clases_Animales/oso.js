import { Animal } from "./animal.js";

export class Oso extends Animal{
    constructor(nombre, edad, imagen, comentarios, sonidos){
        super(nombre, edad, imagen, comentarios, sonidos);
    }

    grunir(){
        this.getSonido();
    }
}