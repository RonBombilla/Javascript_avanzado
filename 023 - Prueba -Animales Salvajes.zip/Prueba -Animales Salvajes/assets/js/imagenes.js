import allData from './DB.js'

//Interacción con la imagenes

const animal = document.getElementById('animal');
const preview = document.getElementById('preview');


animal.addEventListener('change', async() => {
    const { animales } = await allData.getData();
    const nombreAnimal = animal.value;
    const animalSelected = animales.find(animal => animal.name === nombreAnimal);
    const animalImage = animalSelected.imagen;
    const animalPath = `./assets/imgs/${animalImage}`;
    createImage(animalPath)
    console.log(animalPath);
})


const createImage = (path) => {
    preview.innerHTML = '';
    preview.style.backgroundImage = `url(${path})`
}

export default {}