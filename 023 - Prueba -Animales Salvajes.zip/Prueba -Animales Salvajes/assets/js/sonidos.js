import allData from './DB.js'

const getAnimalSound = async(animal) => {
    const { animales } = await allData.getData();
    const { sonido } = await animales.find(e => e.name === animal)
    return sonido
}




export default getAnimalSound