const Url = 'https://randomuser.me/api/?results=10'
const getItems = (async() => {
    try {
        const res = await fetch(Url);
        const data = await res.json();
        //console.log(data.results);
        createData(data.results)
    } catch (error) {
        console.log(error);
    }

})();

const users = document.getElementById('usersData');
const createData = (data) => {
    data.forEach(element => {
        console.log(element);
        users.innerHTML += 
            `
        <img src="${element.picture.large}">
        <p>${element.name.first} ${element.name.last}</p>
        <p>${element.email}</p>
        <p>${element.phone}</p>
        `
    });
}