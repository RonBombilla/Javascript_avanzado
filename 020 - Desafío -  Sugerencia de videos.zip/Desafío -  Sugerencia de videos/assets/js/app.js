let metodoPrincipal = (() => {
    let agregarDatos = (url, id) => {
        id.setAttribute('src', url);
        id.style.display = 'block';
    };

    return {
        mostrarDatos: (url, id) => {
            return agregarDatos(url, id)
        }
    };
})();

class Multimedia {
    constructor(url) {
        let _url = url;

        this.getUrl = () => _url;
    };

    get url() {
        return this.getUrl();
    };

    setInicio() {
        return `Este método es para realizar un cambio en la URL del video`
    };
};

class Reproductor extends Multimedia {
    constructor(url, id) {
        super(url);
        let _id = id;

        this.getId = () => _id;
    };
    playMultimedia() {
        metodoPrincipal.mostrarDatos(this.url, this.getId());
    };
    setInicio(tiempo) {
        this.getId().setAttribute('src', `${this.url}?start=${tiempo}`)
    };
};




let video1 = new Reproductor("https://www.youtube.com/embed/7QU1nvuxaMA?start=9", musica);
video1.playMultimedia();
let video2 = new Reproductor("https://www.youtube.com/embed/vM-Bja2Gy04?start=9", peliculas);
video2.playMultimedia();
let video3 = new Reproductor("https://www.youtube.com/embed/ETY44yszyNc?start=9", series);
video3.playMultimedia();