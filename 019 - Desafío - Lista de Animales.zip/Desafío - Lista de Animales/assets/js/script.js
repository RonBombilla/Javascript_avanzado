class Propietario {
    constructor(nombre, direccion, telefono) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.telefono = telefono;
    }

    datosPropietario() {
        return `El nombre del dueño es: ${this.nombre}. El domicilio es: ${this.direccion}, y el número de contacto es: ${this.telefono}`;
    }
}

class Animal extends Propietario {
    constructor(nombre, direccion, telefono, tipo) {
        super(nombre, direccion, telefono);
        this._tipo = tipo;
    }

    get tipo() {
        return `El tipo de animal es un: ${this._tipo}`
    }
}

class Mascota extends Animal {
    constructor(nombre, direccion, telefono, tipo, nombreMascota, enfermedad) {
        super(nombre, direccion, telefono, tipo);
        this._nombreMascota = nombreMascota;
        this._enfermedad = enfermedad;
    }

    get nombreMascota() {
        return `, mientras que el nombre de la mascota es: ${this._nombreMascota}`;
    }

    set nombreMascota(nuevo_nombreMascota) {
        this_nombreMascota = nuevo_nombreMascota;
    }

    get enfermedad() {
        return ` y la enfermedad es: ${this._enfermedad}`;
    }

    set enfermedad(nueva_enfermedad) {
        this._enfermedad = nueva_enfermedad;
    }
}





/*

const propietario = new Propietario('Aaron', 'Las Perdices #4444 Puente Bajo', '+56966514681');

const mascota = new Mascota('Juan', 'Don Pepe #5634', '+56975747372', 'Gato', 'Mesquino', 'Bola de pelos gigante');



console.log(propietario.datosPropietario());

console.log(mascota.datosPropietario(), mascota.tipo, mascota.enfermedad)
*/

//---------------------------------------------------------------------------------------------------------




$('form').submit((event) => {

    event.preventDefault();

    let propietario = document.getElementById('propietario').value;
    let telefono = document.getElementById('telefono').value;
    let direccion = document.getElementById('direccion').value;
    let nombreMascota = document.getElementById('nombreMascota').value;
    let tipo = document.getElementById('tipo').value;
    let enfermedad = document.getElementById('enfermedad').value;
    const mascota1 = new Mascota(propietario, direccion, telefono, tipo, nombreMascota, enfermedad);

    document.querySelector('#resultado').innerHTML = `<ul>${mascota1.datosPropietario()}</ul> 
                                                      <ul>${mascota1.tipo} ${mascota1.nombreMascota}  ${mascota1.enfermedad}</ul>`;

});