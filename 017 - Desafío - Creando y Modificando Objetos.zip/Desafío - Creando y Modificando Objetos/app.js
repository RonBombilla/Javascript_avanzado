//Código de Consultorio

function Consultorio(nombre, paciente) {
    let _nombre = nombre;
    let _paciente = paciente || [];


    Object.defineProperty(this, "_getNombre", {
        get: function() {
            return _nombre;
        }
    });

    Object.defineProperty(this, "_setNombre", {
        set: function(nombre) {
            _nombre = nombre;
        }
    });

    Object.defineProperty(this, "_getPaciente", {
        get: function() {
            return _paciente;
        }
    });

    Object.defineProperty(this, "_setPaciente", {
        set: function(paciente) {
            _paciente = paciente;
        }
    });

}

Consultorio.prototype.addPaciente = function(paciente) {
    this.paciente.push(paciente)
}

Paciente.prototype.getPaciente = function() {
    return this._getPaciente;
}


//Código de Paciente

function Paciente(nombre, edad, rut, diagnostico) {
    let _nombre = nombre;
    let _edad = edad;
    let _rut = rut;
    let _diagnostico = diagnostico;

    Object.defineProperty(this, "_getNombre", {
        get: function() {
            return _nombre;
        }
    });

    Object.defineProperty(this, "_nombre", {
        get: function() {
            return _nombre;
        }
    });

    Object.defineProperty(this, "_getEdad", {
        get: function() {
            return _edad;
        }
    });

    Object.defineProperty(this, "_getRut", {
        get: function() {
            return _rut;
        }
    });

    Object.defineProperty(this, "_getDiagnostico", {
        get: function() {
            return _diagnostico;
        }
    });

}

Consultorio.prototype.setGuardarArreglo = (N_arreglo) => {
    Paciente._pacienteDatos = () => {
        return N_arreglo;
    }
}

Paciente.prototype.getNombrePaciente = function() {
    return this._nombre;
}

Consultorio.prototype.nombreClinica = function() {
    console.log(this._getNombre);
}

const nuevoPaciente1 = new Paciente('Aaron', 30, 17832824 - 7, 'Gastritis');
const nuevoPaciente2 = new Paciente('Juan', 29, 18932564 - 1, 'Fractura');
const nuevoPaciente3 = new Paciente('Sebastian', 24, 21157463 - 8, 'Resfrio');
const nuevoPaciente4 = new Paciente('Jose', 27, 19457311 - 4, 'Sinusitis');
const nuevoPaciente5 = new Paciente('Almendra', 28, 18456327 - 2, 'Anemia');

const datosPaciente = new Consultorio('CLinica 1', 'paciente1');

console.log(nuevoPaciente1.getNombrePaciente);
console.log(nuevoPaciente2._getNombre);

console.log(datosPaciente._getNombre);
datosPaciente.nombreClinica();