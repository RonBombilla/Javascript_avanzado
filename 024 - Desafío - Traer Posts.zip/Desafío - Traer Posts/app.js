const Url = 'https://jsonplaceholder.typicode.com/posts'
const postData = document.getElementById('postData')
const request = async() => {
    try {
        const response = await fetch(Url);
        const data = await response.json();
        newPost(data);
    } catch (error) {
        console.error(error);
    }

}

const newPost = (data) => {
    postData.innerHTML = ''
    postData.innerHTML += /*HTML*/
        `
        <ul id ='list'>
        </ul>`;
    const list = document.getElementById('list')
    data.forEach(element => {
        list.innerHTML += /*HTML*/
            `<li><strong>${element.title}</strong>
                <p>${element.body}</p>    
            </li>
        `
    });
}

const getPosts = async() => {
    await request();
}