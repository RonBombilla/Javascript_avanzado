import Impuestos from './impuestos.js'
import Cliente from './cliente.js'

var impuesto = new Impuestos(20000, 231)
var cliente = new Cliente('Pedrito, ', impuesto);

console.log(cliente.nombre, cliente.calcularImpuesto())