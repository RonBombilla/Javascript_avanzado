//1. Constante URL
const datosUrl = ('https://jsonplaceholder.typicode.com/photos')

//2./3. Función asíncrona - try/catch
const getData = async(datosUrl) => {
    try {
        const response = await fetch(datosUrl);
        const data = await response.json();
        return data;
    } catch (error) {
        return error;
    }
}


//4. Conseguir 20 primeros datos
const obtenerDatos = async(data) => {
    const ob = await data
    const twenty = []
    for (let index = 0; index < 20; index++) {
        twenty.push(ob[index])
    }
    return twenty;
}

//5. Promesa setTimeout
const tiempo = () => new Promise((resolve, reject) => {
    setTimeout(() => resolve('Información Enviada'), 3000)
})



//6. Función asíncrona para mostrar los datos obtenidos en punto 4.
const principal = async(datos) => {
    await datos.then(success => {
        console.log(success);
    })
    const veinte = await obtenerDatos(getData(datosUrl));
    console.log(veinte);
}

principal(tiempo());